var searchData=
[
  ['revision_20history_20of_20cmsis_2dcore',['Revision History of CMSIS-CORE',['../core_revision_history.html',1,'']]],
  ['register_20mapping',['Register Mapping',['../_reg_map_pg.html',1,'']]]
];

var searchData=
[
  ['kernel_20information_20and_20control',['Kernel Information and Control',['../group___c_m_s_i_s___r_t_o_s___kernel_ctrl.html',1,'']]]
];

var group__variance =
[
    [ "arm_var_f32", "group__variance.html#ga393f26c5a3bfa05624fb8d32232a6d96", null ],
    [ "arm_var_q15", "group__variance.html#ga79dce009ed2de28a125aeb3f19631654", null ],
    [ "arm_var_q31", "group__variance.html#gac02873f1c2cc80adfd799305f0e6465d", null ]
];
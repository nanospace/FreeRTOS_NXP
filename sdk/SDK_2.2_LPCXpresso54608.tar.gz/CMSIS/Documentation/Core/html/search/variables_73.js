var searchData=
[
  ['scr',['SCR',['../struct_s_c_b___type.html#a3a4840c6fa4d1ee75544f4032c88ec34',1,'SCB_Type']]],
  ['shcsr',['SHCSR',['../struct_s_c_b___type.html#a7b5ae9741a99808043394c4743b635c4',1,'SCB_Type']]],
  ['shp',['SHP',['../struct_s_c_b___type.html#a85768f4b3dbbc41fd760041ee1202162',1,'SCB_Type']]],
  ['sleepcnt',['SLEEPCNT',['../struct_d_w_t___type.html#a416a54e2084ce66e5ca74f152a5ecc70',1,'DWT_Type']]],
  ['sppr',['SPPR',['../struct_t_p_i___type.html#a12f79d4e3ddc69893ba8bff890d04cc5',1,'TPI_Type']]],
  ['spsel',['SPSEL',['../union_c_o_n_t_r_o_l___type.html#a8cc085fea1c50a8bd9adea63931ee8e2',1,'CONTROL_Type']]],
  ['sspsr',['SSPSR',['../struct_t_p_i___type.html#a7b72598e20066133e505bb781690dc22',1,'TPI_Type']]],
  ['stir',['STIR',['../struct_n_v_i_c___type.html#a37de89637466e007171c6b135299bc75',1,'NVIC_Type']]],
  ['systemcoreclock',['SystemCoreClock',['../group__system__init__gr.html#gaa3cd3e43291e81e795d642b79b6088e6',1,'Ref_SystemAndClock.txt']]]
];

var searchData=
[
  ['misra_2dc_3a2004_20compliance_20exceptions',['MISRA-C:2004 Compliance Exceptions',['../_m_i_s_r_a_compliance.html',1,'Overview']]]
];

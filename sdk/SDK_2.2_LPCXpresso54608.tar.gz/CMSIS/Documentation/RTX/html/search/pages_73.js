var searchData=
[
  ['svc_20functions',['SVC Functions',['../_s_v_c_functions.html',1,'Configure']]],
  ['system_20configuration',['System Configuration',['../_system_config.html',1,'Configure']]]
];

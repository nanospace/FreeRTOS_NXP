var group___r_t_x___global___functions =
[
    [ "os_error", "group___r_t_x___global___functions.html#ga651ae76b3acf45f80bf0e0487b51d6e6", null ],
    [ "os_idle_demon", "group___r_t_x___global___functions.html#gafb4dc4d3dff8343a393726d2860282e4", null ],
    [ "os_resume", "group___r_t_x___global___functions.html#ga1b85a217d43e6b971ffcf24f8aae1c33", null ],
    [ "os_suspend", "group___r_t_x___global___functions.html#ga3e9c57746ccbdfe90464ad50513c569e", null ],
    [ "os_tick_init", "group___r_t_x___global___functions.html#ga145e7eafdd042bb522020cbb3b469d9c", null ],
    [ "os_tick_irqack", "group___r_t_x___global___functions.html#ga85dab8408f27236c7341a69feb6258c7", null ],
    [ "os_tick_ovf", "group___r_t_x___global___functions.html#gad5deddec3fea0fb31798f571afc3c692", null ],
    [ "os_tick_val", "group___r_t_x___global___functions.html#ga567543bf38239a91f09751686c23017b", null ]
];
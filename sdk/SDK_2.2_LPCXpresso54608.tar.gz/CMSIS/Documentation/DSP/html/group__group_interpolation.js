var group__group_interpolation =
[
    [ "Linear Interpolation", "group___linear_interpolate.html", "group___linear_interpolate" ],
    [ "Bilinear Interpolation", "group___bilinear_interpolate.html", "group___bilinear_interpolate" ]
];